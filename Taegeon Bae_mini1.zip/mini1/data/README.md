
Raw data file name:
pc_sales_2024.xlsx

Cleaned data file name:
my_clean_data.csv

Date downloaded:
9/22/2025

Description:
This dataset contains the sales of new passenger cars by country from 2019 to 2024.
The raw excel sheet has been cleaned by removing regional totals, footnotes, and blank rows.
It has been pivoted from wide to long format, and has chronological ordering by year.
The dataset includes annual sales counts by country.

Link to downloaded file:
https://www.oica.net/wp-content/uploads/pc_sales_2024.xlsx
Dictionary of cleaned data file:

variable | description
---------|------------------
country  |Name of country (Argentina, Japan, China, etc)
year     |Calendar year of sales (2019-2024)
sales    |Number of passenger cars sold in that country and year
